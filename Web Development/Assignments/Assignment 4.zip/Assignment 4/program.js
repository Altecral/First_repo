// Alejandro Manrique Assignment 4
console.log("JavaScript code is running");

var totalPokemon;
var currentPokemonIndex;
var pokeGallery = {
    pokeData: "5",
    pokePrefix: "Null",
    pokeSlides: "5",
    init: function () {
        console.log("pokeGallery.init() is called");
        $.ajax({
            url: "./images.txt",
            async: true,
            success: function (data) {
                console.log("AJAX request is successful");
                console.log("Data received from images.txt:", data);
                pokeGallery.pokeData = data.split('\n');
                totalPokemon = pokeGallery.pokeData.length;
                currentPokemonIndex = 0;
                updatePokeImage();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log("AJAX request failed:", textStatus, errorThrown);
            }
        });

    }
};

pokeGallery.init();

function updatePokeImage() {
    var pokeImage = document.getElementById("pokeImage");
    console.log("updatePokeImage() is called");
    console.log("Current Pokémon image file:", pokeGallery.pokeData[currentPokemonIndex].split(' ')[0]);
    
    // Fade out animation
    pokeImage.classList.remove("visible");
    setTimeout(function () {
        // Update image source and fade in animation
        pokeImage.setAttribute("src", "./images/" + pokeGallery.pokeData[currentPokemonIndex].split(' ')[0]);
        pokeImage.classList.add("visible");
        setTimeout(function () {
            nextPokemon();
        }, pokeGallery.pokeData[currentPokemonIndex].split(' ')[1]);
    }, 1000);
}

function previousPokemon() {
    if (currentPokemonIndex == 0) {
        currentPokemonIndex = totalPokemon - 1;
    } else {
        currentPokemonIndex--;
    }
    updatePokeImage();
};

function nextPokemon() {
    if (currentPokemonIndex == totalPokemon - 1) {
        currentPokemonIndex = 0;
    } else {
        currentPokemonIndex++;
    }
    updatePokeImage();
};

setTimeout(function () {
    nextPokemon();
}, 3000);
