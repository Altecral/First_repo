function drawTable() {
    var rows = document.getElementById("rows").value;
    var cols = document.getElementById("cols").value;
    var table = document.getElementById("table");
    table.innerHTML = "";
    for (var i = 0; i < rows; i++) {
      var row = table.insertRow();
      for (var j = 0; j < cols; j++) {
        var cell = row.insertCell();
        cell.innerHTML = (i+1) * (j+1);
      }
    }
  }
  