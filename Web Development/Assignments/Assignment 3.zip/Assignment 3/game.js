/*
    Assignment 3
    Author: Alejandro Manrique
    Date:   2023-04-02
    Filename: index.html
*/

// Create a canvas element to draw graphics on
var canvas = document.createElement("canvas");
var ctx = canvas.getContext("2d");
canvas.width = 640;
canvas.height = 544;
document.getElementById("theCanvas").appendChild(canvas);

canvas.style.cursor = "url('images/mouse.png'), auto";
// Load the background image
var bgReady = false;
var bgImage = new Image();
bgImage.onload = function () {
    bgReady = true;
};
bgImage.src = "images/background.png";

// Load the bug image
var bugReady = false;
var bugImage = new Image();
bugImage.onload = function () {
    bugReady = true;
};
bugImage.src = "/images/pokemon.png";

// Initialize the score and hopping interval
var score = 0;
// Set up hopping
var hopInterval = 2000;
// Define the bug object
var hop = setInterval(function () {
    resetLocation();
}, hopInterval);

var bug = {
    speed: 256 // movement in pixels per second
};

// Handle mouse click events to check if the user clicked on the bug
canvas.addEventListener("mousedown", clicked, false);
function clicked(e) {
    e.preventDefault();
    // Get the location of the mouse click
    var x = e.clientX;
    var y = e.clientY;

    // check if the player clicked on the bug
    if (x > bug.x && x < bug.x + 61 && y > bug.y && y < bug.y + 169) {
        // increment score by 10
        score += 10;
        resetLocation();
        // reduce hop interval, but should not be less than 0
        if (hopInterval - 100 >= 50) {
            clearInterval(hop);
            hopInterval -= 100;
            hop = setInterval(function () {
                resetLocation();
            }, hopInterval);

        }
    }
}

// Reset the bug location when the player restarts or catches a bug
var resetLocation = function () {
    // randome number to put the bug on any part of the screen
    bug.x = 32 + (Math.random() * (canvas.width - 64));
    bug.y = 32 + (Math.random() * (canvas.height - 64));
};

// this will reset the bug for moving 
var resetSpeed = function () {
    clearInterval(hop);
    hopInterval = 2000;
    hop = setInterval(function () {
        resetLocation();
    }, hopInterval);
};
var resetScore = function () {
    score = 0;
    //this will reset the speed option
    resetSpeed();
};

// Draw everything
var render = function () {
    if (bgReady) {
        ctx.drawImage(bgImage, 0, 0);
    }

    if (bugReady) {
        ctx.drawImage(bugImage, bug.x, bug.y);
    }

    // Score
    ctx.fillStyle = "rgb(0, 0, 250)";
    ctx.font = "24px Helvetica";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    document.getElementById("score").innerHTML = "Score : " + score;
};

// The main loop, here we set the main loop for the game
var main = function () {
    render();

    // Request to do this again ASAP
    requestAnimationFrame(main);
};

// set the support for requestAnimationFrame
var w = window;
requestAnimationFrame = w.requestAnimationFrame || w.webkitRequestAnimationFrame
        || w.msRequestAnimationFrame || w.mozRequestAnimationFrame;

// lets call the main function to play the game.
main();
