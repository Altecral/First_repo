"use strict";
/*    JavaScript 7th Edition
      Chapter 5
      Chapter Case

      Image List

      Filename:lightbox_data.js
*/

// Title of the slideshow
let lightboxTitle = "My Pokemon Collection";



// Names of the image files shown in the slideshow
let imgFiles = ["pk1.png", "pk2.png", "pk3.png", "pk4.png",
                "pk5.png", "pk6.png", "pk7.png", "pk8.png",
                "pk9.png", "pk10.png", "pk11.png", "pk12.png"]

// Captions associated with each image
let imgCaptions = new Array(12);
imgCaptions[0]="Bulbasaur";
imgCaptions[1]="Ivysaur"; 
imgCaptions[2]="Venusaur"; 
imgCaptions[3]="Charmander"; 
imgCaptions[4]="Charmeleon";
imgCaptions[5]="Charizard";
imgCaptions[6]="Squirtle";
imgCaptions[7]="Wartortle";
imgCaptions[8]="Blastoise";
imgCaptions[9]="Caterpie";
imgCaptions[10]="Metapod";
imgCaptions[11]="Butterfree";

// Count of images in the slideshow
let imgCount = imgFiles.length;
