"use strict";
/*    JavaScript 7th Edition
      Chapter 6
      Project 06-01

      Project to validate a form used for setting up a new account
      Author: Alejandro Manrique
      Date:   23/03/12 

      Filename: project06-01.js
*/

const submitButton = document.getElementById("submitButton");
const pwd = document.getElementById("pwd");
const pwd2 = document.getElementById("pwd2");
submitButton.addEventListener("click", function() {
      const pwdPattern = /^(?=.[A-Za-z])(?=.\d)[A-Za-z\d]{8,}$/;
      
      if (!pwdPattern.test(pwd.value)) {
      validation.innerHTML = "Your password must be at least 8 characters with at least one letter and one number";
      } else if (pwd.value !== pwd2.value) {
      validation.innerHTML = "Your passwords must match";
      } else {
      validation.innerHTML = "";
      }
      });
