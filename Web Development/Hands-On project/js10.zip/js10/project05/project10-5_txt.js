"use strict";
/*  JavaScript 7th Edition
    Chapter 10
    Project 10-05

    Crossword Puzzle Code for Keyboard Actions

    Author: Alejandro Manrique
    Date:   04/16/2023  

    Filename: project10-05.js
*/

document.addEventListener("keydown", selectLetter);

// Function to navigate with key.
function selectLetter(e) {

    e.preventDefault();

    let leftLetter = document.getElementById(currentLetter.dataset.left);

    let upLetter = document.getElementById(currentLetter.dataset.up);

    let rightLetter = document.getElementById(currentLetter.dataset.right);

   
    let downLetter = document.getElementById(currentLetter.dataset.down);

    // Get the key 
    let userKey = e.key;

    if (userKey === "ArrowLeft") { // Move left
        formatPuzzle(leftLetter);

    } else if (userKey === "ArrowUp") { // Move up
        formatPuzzle(upLetter);

    } else if (userKey === "ArrowRight" || userKey === "Tab") { // Move right
        formatPuzzle(rightLetter);

    } else if (userKey === "ArrowDown" || userKey === "Enter") { // Move down
        formatPuzzle(downLetter);

    } else if (userKey === "Backspace" || userKey === "Delete") { 
        currentLetter.textContent = "";

    } else if (userKey === " ") { 
        switchTypeDirection();

    } else if (userKey >= "a" && userKey <= "z") { 
        currentLetter.textContent = userKey.toUpperCase();

        if (typeDirection === "right") {
            formatPuzzle(rightLetter);  
        } else {
            formatPuzzle(downLetter);  
        }
    }

}
