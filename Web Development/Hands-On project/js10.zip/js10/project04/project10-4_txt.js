"use strict";
/*  JavaScript 7th Edition
    Chapter 10
    Project 10-04

    Chess Board Drag and Drop

    Author: Alejandro Manrique
    Date:   04/16/2023  

    Filename: project10-04.js
*/

// Page Objects
let pieces = document.getElementsByTagName("span");
let boardSquares = document.querySelectorAll("table#chessboard td");
let whiteBox = document.getElementById("whiteBox");
let blackBox = document.getElementById("blackBox");

// Iterate through all the pieces
for (let piece of pieces) {
  // Set the draggable property to true
  piece.draggable = true;

  // Create event handler for dragstart event
  piece.addEventListener("dragstart", (event) => {
    event.dataTransfer.setData("text/plain", event.target.id);
  });
}

// Iterate through all the board squares
for (let square of boardSquares) {
  // Create event handler for dragover event
  square.addEventListener("dragover", (event) => {
    event.preventDefault();
  });

  // Create event handler for drop event
  square.addEventListener("drop", (event) => {
    // Prevent default action for drop event
    event.preventDefault();

    // Get the pieceID from dataTransfer object
    let pieceID = event.dataTransfer.getData("text/plain");

    // Get the movingPiece element by ID
    let movingPiece = document.getElementById(pieceID);

    // Check if the event target is an empty square
    if (event.target.tagName === "TD") {
      event.target.appendChild(movingPiece);
    } else if (event.target.tagName === "SPAN") {
      // Store occupyingPiece and its parent square
      let occupyingPiece = event.target;
      let parentSquare = occupyingPiece.parentElement;

      // Append movingPiece as a child of parentSquare
      parentSquare.appendChild(movingPiece);

      // Move the occupying piece back to the appropriate box
      if (occupyingPiece.className === "white") {
        whiteBox.appendChild(occupyingPiece);
      } else {
        blackBox.appendChild(occupyingPiece);
      }
    }
  });
}
