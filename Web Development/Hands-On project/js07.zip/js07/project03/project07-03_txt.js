"use strict";
/*    JavaScript 7th Edition
      Chapter 7
      Project 07-03

      Project to create a New Year's Eve countdown clock
      Author: Alejandro Manrique
      Date:   2023/03/26

      Filename: project07-03.js
*/

let currentTime = document.getElementById("currentTime");
let daysLeftBox = document.getElementById("days");
let hrsLeftBox = document.getElementById("hours");
let minsLeftBox = document.getElementById("minutes");
let secsLeftBox = document.getElementById("seconds");
let newYear = new Date("January 1, 2024");

function countdown() {
   let now = new Date();
   let nextYear = now.getFullYear() + 1;
   newYear.setFullYear(nextYear);
   let timeRemaining = newYear.getTime() - now.getTime();
   let days = timeRemaining / (1000 * 60 * 60 * 24);
   let hours = (days - Math.floor(days)) * 24;
   let minutes = (hours - Math.floor(hours)) * 60;
   let seconds = (minutes - Math.floor(minutes)) * 60;

   currentTime.textContent = now.toLocaleString();

   daysLeftBox.textContent = Math.floor(days);
   hrsLeftBox.textContent = Math.floor(hours);
   minsLeftBox.textContent = Math.floor(minutes);
   secsLeftBox.textContent = Math.floor(seconds);

   if (timeRemaining < 0) {
      daysLeftBox.textContent = "0";
      hrsLeftBox.textContent = "0";
      minsLeftBox.textContent = "0";
      secsLeftBox.textContent = "0";
      clearInterval(interval);
      document.getElementById("countdown").textContent = "The deadline has passed!";
   }
}

countdown();

let interval = setInterval(countdown, 1000);
