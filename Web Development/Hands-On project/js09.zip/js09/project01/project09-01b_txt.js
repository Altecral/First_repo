"use strict";
/*    JavaScript 7th Edition
      Chapter 9
      Project 09-01

      Project to read field values from a query string
      Author: Alejandro Manrique 
      Date:   04/08/2023

      Filename: project09-01b.js
*/
// Step 1: Get the query string from the URL
var query = location.search;

// Step 2: Remove the first character from the query string
query = query.slice(1);

// Step 3: Replace all occurrences of '+' with ' ' and decode the URI-encoded string
query = decodeURIComponent(query.replace(/\+/g, ' '));

// Step 4: Split the query string at every '&' character to create an array of key-value pairs
var cardFields = query.split('&');

// Step 5: Loop through each key-value pair
for (var i = 0; i < cardFields.length; i++) {
  // Step 6: Split each key-value pair at the '=' character to separate the key and value
  var nameValue = cardFields[i].split('=');
  
  // Step 7: Get the element with the id equal to the key and set its text content to the value
  var name = nameValue[0];
  var value = nameValue[1];
  document.getElementById(name).textContent = value;
}




