"use strict";
/* JavaScript 7th Edition
 * Chapter 9 - Project 9-4
 * Sliding Block Puzzle Game
 * Author: Alejandro Manrique
 * Date:   04/08/2023
 * Filename: project09-04.js
 */

/* Page Variables */
let solution = ["10", "11", "12", "13", "20", "21", "22", "23", "30", "31", "32", "33", "00"];
let pieces = document.querySelectorAll(".puzzlepiece");
let emptyX = 3;
let emptyY = 3;
let bestText = document.getElementById("bestText");

/* Event Listeners */
window.addEventListener("load", function () {
  // If the document.cookie object exists
  if (document.cookie) {
    bestText.textContent = "best " + getBestTime() + " seconds";
  }
  for (let i = 0; i < pieces.length; i++) {
    pieces[i].addEventListener("click", movePiece);
  }
});

/* Function Declarations */

// Function to move puzzle pieces
function movePiece() {
  let x = parseInt(this.style.left) / 100;
  let y = parseInt(this.style.top) / 100;
  if ((x === emptyX && Math.abs(y - emptyY) === 1) || (y === emptyY && Math.abs(x - emptyX) === 1)) {
    this.style.left = emptyX * 100 + "px";
    this.style.top = emptyY * 100 + "px";
    let newX = x;
    let newY = y;
    emptyX = newX;
    emptyY = newY;
    updateRecord();
  }
}

// Function to retrieve best time from cookies
function getBestTime() {
      var cookieArray = document.cookie.split("=");
      if (cookieArray[0] == "puzzle8Best") {
         return parseInt(cookieArray[1]);
      } else {
         return 9999;
      }
}

function updateRecord() {
  let solutionTime = parseInt(document.getElementById("timer").textContent);
  let bestTime = getBestTime();
  if (solutionTime < bestTime) {
    bestTime = solutionTime;
  }
  bestText.textContent = "best " + bestTime + " seconds";
  let expiresDate = new Date();
  expiresDate.setDate(expiresDate.getDate() + 90);
  let cookieValue = "puzzle8Best=" + bestTime + ";expires=" + expiresDate.toUTCString() + ";path=/";
  document.cookie = cookieValue;
  document.cookie = "puzzle8Best=" + bestTime + "; max-age=" + (90 * 24 * 60 * 60);
}
