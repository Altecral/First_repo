"use strict";
/*    JavaScript 7th Edition
      Chapter 9
      Project 09-03

      Project to retrieve date of last visit from web storage and mark new article
      Author: Alejandro Manrique 
      Date:   04/08/2023   

      Filename: project09-03.js
*/

/* Page Objects */

let lastVisitDate = document.getElementById("lastVisitDate");
let articleDates = document.getElementsByClassName("posttime");

/* Check for last visit date in local storage */
if (localStorage.sbloggerVisit) {
  /* Retrieve last visit date from local storage */
  let storedLastDate = localStorage.getItem("sbloggerVisit");
  
  /* Display last visit date */
  lastVisitDate.innerHTML = "Last visit: " + storedLastDate;
  
  /* Convert last visit date to Date object */
  let lastDate = new Date(storedLastDate);
  
  /* Loop through article dates to mark new articles */
  for (let articleDate of articleDates) {
    /* Convert article date to Date object */
    let currentDate = new Date(articleDate.innerHTML);
    if (currentDate > lastDate) {
      articleDate.innerHTML += " <strong>new</strong>";
    }
  }
} else {
  /* Display welcome message */
  lastVisitDate.innerHTML = "Welcome to SBlogger!";
  
  /* Loop through article dates to mark all as new */
  for (let articleDate of articleDates) {
    articleDate.innerHTML += " <strong>new</strong>";
  }
}

/* Update stored date value in local storage */
let currentDate = new Date("9/12/2024");
let dateString = currentDate.toLocaleDateString();
localStorage.setItem("sbloggerVisit", dateString);
